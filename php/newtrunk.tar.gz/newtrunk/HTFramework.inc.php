<?php
/**
 *  HTFramework.inc.php
 *  The only file required for HTFramework functionality. This file includes
 *  other class definition files as they are referenced by client (non-framework)
 *  code. This is done dynamically by PHP using the __autoload function.
 *  @package HTFramework
 *  @subpackage HTCommon 
 *  @filesource      
 * 
 */ 

/**
 *  Framework Defines
*/
/**
 *  Define this boolean as true for the development phase of your project.
 *  This define should always be false for the production version of this file. 
*/
error_reporting(E_ALL ^ E_NOTICE);
//error_reporting(E_ALL);
//define (HTFRK_FRAMEWORK_DEBUG, true);

define ('DOC_FILE_EXT', 'xml');
define ('RESOURCE_EXT', 'php');
define ('DOC_SERVER', 'http://localhost/exampleXMLmodel');
define ('DOC_NAME_PARAM', 'docname');
define ('DOC_FILE_PATH', 'C:/Dev/workspace/php/Libraries/Framework/HTDb/XML');
define ('HTLIB_PATH', 'Libraries/');
define ('HTFRK_PATH', 'Libraries/Framework/');
define ('HTFRK_DB_PATH', 'Libraries/Framework/HTDb/');
define ('HTFRK_EX_NOTICE', 5);
define ('HTFRK_EX_WARNING', 10);
define ('HTFRK_EX_STOP', 15);


/**
 *
 *  The Framework uses the convention of one PHP source file per-class definition
 *  PHP calls the __autoload function whenever a class is referenced which hasn't 
 *  been defined yet.  
 *  
 *  When you add a class to the Framework, add a _require_once call for it here.   
*/
function __autoload($class_name) {
  switch($class_name)
  {
    case 'TableTemplate':
      require_once HTLIB_PATH . $class_name . '.class.php';
      break;
    // These classes are in the Framework top level directory
    // For convience the HTModel interface and class are in same file
    case 'iHTModel' :
    case 'clsHTModel' :
      require_once HTFRK_PATH . 'HTModel.class.php';
      break;
    case 'HTException':
    case 'HTQuickFormsExt':
    case 'HTConfig' :
    case 'HTResult' :
    case 'SolModel' :
    case 'ConSolModel' :
    case 'DwhModel' :
    case 'XMLModel' :
    case 'scrollTable':
    case 'HTDate' :
      require_once HTFRK_PATH . $class_name . '.class.php';
      break;
    // These classes are in the Framework database logical (entity) directory
    // Under test:
    case 'HTExportCertModel':
    case 'HTTallyModel':
    case 'INConvModel':
    case 'Batch':
    case 'ARSetup':
    case 'ReportClassModel':
    case 'SalesOrd':
    case 'SalesOrderDetail':
    case 'StatSumModel':
    case 'StatHdrModel':
    case 'StatDetModel':
    case 'PlyWallDat':
    case 'STax':
    case 'DocSTax':
    case 'CustomerModel':
    case 'TermsModel':
    case 'ArsetupModel':
    case 'Treatment':
    case 'ARDoc':
    case 'ARTran';
    case 'DelTckModel';
    case 'OpenOrderInfo';
    case 'SOBLHdrModel';
    case 'SOBLDetModel';
    // Not under test:
    case 'MeterReadings' :
    case 'MeterReading' :
    case 'Meters' :
    case 'OrderSum' :
    case 'CRMCalls':
    case 'AcctPeriods':
    case 'negunreceived' :
    case 'KilnDWH' :
    case 'Location' :
    case 'Vendor' :
    case 'APDoc' :
    case 'APTran' :
    case 'APSetUp' :
    case 'AdjRpt' :
    case 'APNew' :
    case 'RecTkt' :
    case 'APRecTkt' :
    case 'RecTktDetl' :
    case 'RecTktLog' :
    case 'RecTktEdit' :
    case 'ChkPrtDat' :
    case 'TreatChem' :
    case 'TruckA' :
    case 'TruckB' :
    case 'TruckC' :
    case 'TruckD' :
    case 'TruckE' :
    case 'TruckF' :
    case 'TruckH' :
    case 'SalesPerson' :
    case 'htRcvTckHdr' : 
    case 'htRcvTckDet' :
    case 'TktDetBld' :
    case 'MaintLabel' :
    case 'MaintHead' :
    case 'MaintRecHdr' :
    case 'MaintRecDeta' :
    case 'MaintRecDetb' :
    case 'MaintRecDetc' :
    case 'MaintRecDetd' : 
    case 'HITrialBal' :
     
      require_once HTFRK_DB_PATH . $class_name . '.class.php';
      break;
    // Here we try to find any class in the include directory(s)
    default :
      require_once $class_name . '.class.php';
    }
}

function isRemoteXMLDoc($docSourceName) 
{
	$ret = false;
  switch($class_name)
  {
    case 'invmvt.insdeltick.insorderitems' : 
    case '' : 
    	$ret = true;
    	break;
    default :
    	$ret = false;
  }
	return $ret;
}
 /**
  * HTApp Application Object
  * 
  */
class HTApp {
	/**
	 * @class implements Singleton pattern
	 */
  private static $theOnlyInstance;  
  /**
   * Only one app object ever gets instatiated. Use static call to 
   * HTApp::getApp(); to get that object. Clone is not allowed.
   */      
  public static function getApp()
  {
    if(!isset(self::$theOnlyInstance))
      self::$theOnlyInstance = new HTApp();
    return self::$theOnlyInstance;      
  }
	private function __construct() {
		if (HTFRK_FRAMEWORK_DEBUG) {
      error_reporting(E_ALL ^ E_NOTICE);
//      error_reporting(E_ALL);
		} else {
			error_reporting(E_NONE);
		}
	}
  public function __clone()
  {
    trigger_error('Clone is not allowed.', E_USER_ERROR);
  }

	function makeTable($headers,$widths,$height,$detail){
		$table = new TableTemplate();
		echo $table->getTable($widths,$height,$headers,$detail);
	}
}
//$objApp = HTApp::getApp();


?>
