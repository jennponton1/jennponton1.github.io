<?php

/**
 *
 * Used to setup configuration variables for the framework
 * 
 * @package HTFramework
 * @subpackage HTCommon
 * @filesource 
 * 
 */
/**
 *  HTConfig - class 
 *  Act as a single reference for all highly dependent configuration information.
 *    
 */ 
class HTConfig {
	
	var $solDSN = "adohtwsol";
	/**
	 * @var string restoreDSN DSN of up to date Dev Hoover Solomon DB
	 */
	var $restoreDSN = "restore";
	/**
	 * @var string conSolDSN DSN of *Live* Hoover Financial Summary DB
	 */
	var $conSolDSN = 'adoconsol';
	
	/**
	 * @var string solDSN DSN of *Live* Hoover Solomon DB
	 */
  var $liveSolDSN = 'LIVEadohtwsol';
  
  /**
	 * @var string ldapServer IP Address of LDAP Server
	 */
	var $ldapServer = "10.1.1.5";
	/**
	 * @var string dwhServer IP Address of MySQL DB Server
	 */
	var $dwhServer = '10.0.0.1';    // "127.0.0.1";
	/**
	 * @var string dwhDBName Name of MySQL DB for DataWarehouse
	 */
	var $dwhDBName = "dwh";
	/**
	 * @var string dwhDBName Name of MySQL DB for DataWarehouse
	 */
	var $oprDBName = "htOpr";
	/**
	 * @var string dwhDBUser Name of MySQL DB User
	 */
	var $dwhDBUser = "root";
	/**
	 * @var string dwhDBPass Password for MySQL DB User
	 */
	var $dwhDBPass = "";
	/**
	 * @var boolean debug Used to generate Warning/Notice/Error Messages from PHP
	 */
	var $debug = true;
}
?>
