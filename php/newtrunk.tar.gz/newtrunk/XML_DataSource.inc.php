<?php
function XMLNewConnection($connectString)
{
	// Provision is made for other connection types (e.g. REST/RESTful)
	switch($connectString) {
		case 'XML.appData' : return new appDataXMLConn();
		default : throw new Exception('Unrecognized connect string');
	}
}

class appDataXMLConn extends XMLConn
{
}

class XMLConn
{
	public $autoRollback = false;
	public static $debug = false;
	public $transCnt = 0;
	public $lastErrorMsg = ''; 
	public $dsn = '';	
	private $isRemote;
	private $rem;
	private $local;
	private $connected = false;
	private $locName;
	private $docName;
	private $objName;
	
	public function __construct()
	{
	}
	
	public function isConnected()
	{
		return $this->connected;
	}	
	// File based:
	//		fileName.objectName
	// 		NOTE: Folder name is specified in optional parameter or htConfig 
	// REST based:
	//		resourceName.objectName
	//		NOTE: Resource is appended to URL, object name is querry string
	//		
	// define ('DOC_FILE_EXT', 'xml');
	// define ('RESOURCE_EXT', 'php');
	// define ('DOC_SERVER', 'http://localhost/exampleXMLmodel');
	// define ('DOC_NAME_PARAM', 'objname');
	// define ('DOC_FILE_PATH', 'C:/Dev/workspace/php/Libraries/Framework/HTDb/XML')
	public function Connect($in_dsn)
	{
		list($this->locName, $this->docName, $this->objName) =  explode('.', $in_dsn);
		if(isRemoteXMLDoc($in_dsn)) {
			$this->rem = DOC_SERVER . '/' . $this->locName . '.' . RESOURCE_EXT . '?';
			$this->rem .= DOC_NAME_PARAM . '=' . $this->docName;
		}
		else {
			$this->local = DOC_FILE_PATH . '\\';
			$this->local .= $this->locName . '\\';
			$this->local .= $this->docName . DOC_FILE_EXT;
		}
		$this->connected = true;
		return $this->connected;
	}

	public function Execute($Xpath)
	{
		$result = array();
		if(isRemoteXMLDoc($this->resName)) {
			$xmlTxt = file_get_contents($this->rem);
			if(!isset($xmlTxt) || $xmlTxt === false) {
				throw new Exception("Cannot access server: $this->rem");
			}
			else {
				$resAr = simplexml_load_string($xmlTxt);
			}
		}
		else {
			$xmlTxt = file_get_contents($this->local);
			$resAr = simplexml_load_string($xmlTxt);
		}
		$resAr = (array)$resAr;
		$ret = (array)$resAr['htModel'];
		$ret = $ret[$this->objName];
		return $ret;
	}

	public function ErrorMsg()
	{
		return $this->lastErrorMsg;
	}
	
	public function StartTrans()
	{
		$this->transCount++;
	}
	
	public function CompleteTrans()
	{
	}

	public function FailTrans()
	{
	}
}

?>
